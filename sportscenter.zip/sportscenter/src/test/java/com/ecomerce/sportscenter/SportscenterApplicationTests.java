package com.ecomerce.sportscenter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportscenterApplicationTests {

	@Test
	void contextLoads() {
	}

}
